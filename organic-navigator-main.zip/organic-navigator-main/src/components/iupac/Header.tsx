import { motion } from "framer-motion";
import { Atom } from "lucide-react";

const Header = () => {
  return (
    <motion.header
      className="text-center mb-12"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="inline-flex items-center justify-center p-4 chemistry-card mb-6"
        whileHover={{ scale: 1.05, rotate: 5 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <Atom className="h-12 w-12 text-primary" />
      </motion.div>
      
      <motion.h1
        className="text-5xl md:text-6xl font-extrabold text-foreground mb-4"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2, duration: 0.6 }}
      >
        <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          IUPAC Nomenclature
        </span>
      </motion.h1>
      
      <motion.p
        className="text-xl text-muted-foreground max-w-2xl mx-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
      >
        Your Interactive Guide to Organic Chemistry Naming
      </motion.p>
      
      <motion.div
        className="mt-6 flex flex-wrap justify-center gap-2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        {['Interactive', 'Visual', 'Educational', 'Modern'].map((tag, index) => (
          <motion.span
            key={tag}
            className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 + index * 0.1 }}
            whileHover={{ scale: 1.1 }}
          >
            {tag}
          </motion.span>
        ))}
      </motion.div>
    </motion.header>
  );
};

export default Header;