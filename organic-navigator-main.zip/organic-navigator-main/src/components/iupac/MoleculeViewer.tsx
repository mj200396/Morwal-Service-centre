import { motion } from "framer-motion";

interface MoleculeViewerProps {
  svgContent: string;
  locants: Array<{ x: number; y: number; label: string }>;
  highlight?: "chain" | "substituent" | "functional" | "locants" | "none";
  showLocants?: boolean;
  viewBox?: string;
}

const MoleculeViewer = ({ 
  svgContent, 
  locants, 
  highlight = "none", 
  showLocants = false,
  viewBox = "0 0 400 200"
}: MoleculeViewerProps) => {
  
  const processedSvg = svgContent.replace(/id="(\w+)"/g, (match, id) => {
    const strokeColor = 
      highlight === "chain" && id === "chain" ? "hsl(var(--molecule-highlight))" :
      highlight === "substituent" && id === "substituent" ? "hsl(var(--substituent-highlight))" :
      highlight === "functional" && id === "functional" ? "hsl(var(--functional-group))" :
      "hsl(var(--molecule-carbon))";
    
    const strokeWidth = 
      (highlight === "chain" && id === "chain") ||
      (highlight === "substituent" && id === "substituent") ||
      (highlight === "functional" && id === "functional") ? "6" : "4";
    
    return match + ` stroke="${strokeColor}" stroke-width="${strokeWidth}"`;
  });

  return (
    <motion.div
      className="molecule-viewer w-full max-w-2xl mx-auto bg-gradient-to-br from-background/50 to-muted/30 rounded-xl border border-border/50 p-6"
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <svg 
        viewBox={viewBox}
        className="w-full h-auto drop-shadow-sm"
        style={{ minHeight: "200px" }}
      >
        <defs>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        {/* Render the processed SVG content */}
        <g dangerouslySetInnerHTML={{ __html: processedSvg }} />

        {/* Locant numbers */}
        {locants.map((locant, index) => (
          <motion.g key={index}>
            {/* Background circle for better visibility */}
            <motion.circle
              cx={locant.x}
              cy={locant.y - 2}
              r="14"
              fill="hsl(var(--primary))"
              fillOpacity={showLocants ? "0.95" : "0"}
              stroke="white"
              strokeWidth="2"
              initial={{ scale: 0 }}
              animate={showLocants ? { scale: 1 } : { scale: 0 }}
              transition={{ 
                duration: 0.4, 
                delay: showLocants ? index * 0.1 : 0,
                type: "spring",
                stiffness: 400
              }}
              filter={showLocants ? "url(#glow)" : "none"}
            />
            <motion.text
              x={locant.x}
              y={locant.y + 2}
              fontSize="13"
              fontWeight="bold"
              fill="white"
              textAnchor="middle"
              dominantBaseline="middle"
              initial={{ scale: 0, opacity: 0 }}
              animate={showLocants ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
              transition={{ 
                duration: 0.4, 
                delay: showLocants ? index * 0.1 + 0.1 : 0,
                type: "spring",
                stiffness: 400
              }}
            >
              {locant.label}
            </motion.text>
          </motion.g>
        ))}

        {/* Animated highlighting overlay */}
        {highlight !== "none" && (
          <motion.rect
            x="0" y="0" 
            width="100%" height="100%"
            fill="transparent"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.1, 0] }}
            transition={{ duration: 1.5, repeat: 2 }}
          />
        )}
      </svg>
    </motion.div>
  );
};

export default MoleculeViewer;