import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { GraduationCap, ChevronRight, CheckCircle, XCircle } from "lucide-react";

interface PracticeStep {
  question: string;
  type: "number" | "select";
  options?: string[];
  answer: string | number;
}

interface PracticeMolecule {
  name: string;
  svg: string;
  steps: PracticeStep[];
}

const practiceMolecules: PracticeMolecule[] = [
  {
    name: "3-methylpentane",
    svg: `
      <svg viewBox="0 0 300 150" className="w-full h-auto">
        <path stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" 
              d="M50 100 L100 75 L150 100 L200 75 L250 100"/>
        <line stroke="hsl(var(--molecule-carbon))" strokeWidth="4" 
              x1="150" y1="100" x2="150" y2="135"/>
      </svg>
    `,
    steps: [
      {
        question: "What is the length of the parent chain?",
        type: "number",
        answer: 5
      },
      {
        question: "Are there any double/triple bonds?",
        type: "select",
        options: ["-an- (single)", "-en- (double)", "-yn- (triple)"],
        answer: "-an- (single)"
      },
      {
        question: "What is the substituent?",
        type: "select",
        options: ["methyl", "ethyl", "propyl", "none"],
        answer: "methyl"
      },
      {
        question: "What is the locant of the substituent?",
        type: "number",
        answer: 3
      }
    ]
  },
  {
    name: "Butan-2-ol",
    svg: `
      <svg viewBox="0 0 300 150" className="w-full h-auto">
        <path stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" 
              d="M50 75 L100 100 L150 75 L200 100"/>
        <line stroke="hsl(var(--molecule-carbon))" strokeWidth="4" 
              x1="150" y1="75" x2="170" y2="55"/>
        <text x="175" y="55" fontSize="16" fontWeight="bold" fill="#db2777">OH</text>
      </svg>
    `,
    steps: [
      {
        question: "What is the length of the parent chain?",
        type: "number",
        answer: 4
      },
      {
        question: "What is the principal functional group?",
        type: "select",
        options: ["alcohol (-ol)", "ketone (-one)", "alkene (-ene)"],
        answer: "alcohol (-ol)"
      },
      {
        question: "What is the locant of the -OH group?",
        type: "number",
        answer: 2
      }
    ]
  }
];

const PracticeSection = () => {
  const [currentMoleculeIndex, setCurrentMoleculeIndex] = useState(0);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState<{ type: "success" | "error" | null; message: string }>({ 
    type: null, 
    message: "" 
  });
  const [isComplete, setIsComplete] = useState(false);

  const currentMolecule = practiceMolecules[currentMoleculeIndex];
  const currentStep = currentMolecule.steps[currentStepIndex];

  const checkAnswer = () => {
    const isCorrect = userAnswer.toLowerCase() === String(currentStep.answer).toLowerCase();
    
    if (isCorrect) {
      setFeedback({ type: "success", message: "Correct!" });
      setTimeout(() => {
        if (currentStepIndex < currentMolecule.steps.length - 1) {
          setCurrentStepIndex(currentStepIndex + 1);
          setUserAnswer("");
          setFeedback({ type: null, message: "" });
        } else {
          setIsComplete(true);
        }
      }, 1500);
    } else {
      setFeedback({ type: "error", message: "Not quite, try again!" });
    }
  };

  const nextMolecule = () => {
    setCurrentMoleculeIndex((currentMoleculeIndex + 1) % practiceMolecules.length);
    setCurrentStepIndex(0);
    setUserAnswer("");
    setFeedback({ type: null, message: "" });
    setIsComplete(false);
  };

  return (
    <motion.section
      className="chemistry-card"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="flex items-center gap-4 mb-6"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <GraduationCap className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold text-foreground">Interactive Naming Practice</h2>
      </motion.div>

      <motion.div
        className="max-w-4xl mx-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <div className="molecule-viewer mb-8" dangerouslySetInnerHTML={{ __html: currentMolecule.svg }} />

        <AnimatePresence mode="wait">
          {!isComplete ? (
            <motion.div
              key={currentStepIndex}
              className="space-y-6"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="chemistry-card bg-primary/5 border-primary/20">
                <h3 className="text-lg font-semibold text-foreground mb-4">
                  Step {currentStepIndex + 1} of {currentMolecule.steps.length}
                </h3>
                <p className="text-muted-foreground mb-4">{currentStep.question}</p>

                {currentStep.type === "number" ? (
                  <input
                    type="number"
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border border-border focus:ring-2 focus:ring-primary focus:border-primary"
                    placeholder="Enter your answer"
                  />
                ) : (
                  <select
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border border-border focus:ring-2 focus:ring-primary focus:border-primary"
                  >
                    <option value="">Select an answer</option>
                    {currentStep.options?.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                )}

                <motion.button
                  onClick={checkAnswer}
                  disabled={!userAnswer}
                  className="btn-chemistry mt-4 disabled:opacity-50"
                  whileHover={{ scale: userAnswer ? 1.05 : 1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Check Answer
                </motion.button>
              </div>

              <AnimatePresence>
                {feedback.type && (
                  <motion.div
                    className={`flex items-center gap-3 p-4 rounded-lg ${
                      feedback.type === "success" 
                        ? "bg-success/10 text-success border border-success/20" 
                        : "bg-destructive/10 text-destructive border border-destructive/20"
                    }`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                  >
                    {feedback.type === "success" ? (
                      <CheckCircle className="h-5 w-5" />
                    ) : (
                      <XCircle className="h-5 w-5" />
                    )}
                    <span className="font-semibold">{feedback.message}</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ) : (
            <motion.div
              className="text-center space-y-6"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="chemistry-card bg-success/10 border-success/20">
                <h3 className="text-xl font-bold text-success mb-2">Excellent! You built the name.</h3>
                <p className="text-3xl font-extrabold text-foreground">{currentMolecule.name}</p>
              </div>

              <motion.button
                onClick={nextMolecule}
                className="btn-chemistry flex items-center gap-2 mx-auto"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Next Molecule
                <ChevronRight className="h-4 w-4" />
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.section>
  );
};

export default PracticeSection;