import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

const RulesSection = () => {
  return (
    <motion.section
      className="chemistry-card"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="flex items-center gap-4 mb-6"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <Sparkles className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold text-foreground">Special Rules & Notes</h2>
      </motion.div>

      <motion.p
        className="text-lg text-muted-foreground mb-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        Review important exceptions and rules for more complex molecules.
      </motion.p>

      <motion.div
        className="grid gap-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        {/* Priority Rules */}
        <div className="p-6 bg-primary/5 rounded-xl border border-primary/20">
          <h3 className="text-xl font-semibold text-primary mb-4">Functional Group Priority Order</h3>
          <p className="text-muted-foreground mb-4">
            When multiple functional groups are present, priority determines which becomes the suffix:
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2 text-sm">
              <div className="font-semibold text-primary">Highest Priority:</div>
              <ul className="space-y-1 text-muted-foreground pl-4">
                <li>1. Carboxylic acids (-COOH) → -oic acid</li>
                <li>2. Acid anhydrides → -oic anhydride</li>
                <li>3. Esters (-COO-) → -oate</li>
                <li>4. Acid halides (-COX) → -oyl halide</li>
                <li>5. Amides (-CONH₂) → -amide</li>
              </ul>
            </div>
            <div className="space-y-2 text-sm">
              <div className="font-semibold text-primary">Lower Priority:</div>
              <ul className="space-y-1 text-muted-foreground pl-4">
                <li>6. Aldehydes (-CHO) → -al</li>
                <li>7. Ketones (C=O) → -one</li>
                <li>8. Alcohols (-OH) → -ol</li>
                <li>9. Amines (-NH₂) → -amine</li>
                <li>10. Alkenes (C=C) → -ene</li>
                <li>11. Alkynes (C≡C) → -yne</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Numbering Rules */}
        <div className="p-6 bg-accent/5 rounded-xl border border-accent/20">
          <h3 className="text-xl font-semibold text-accent mb-4">Numbering Rules</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-foreground mb-2">Chain Numbering Priority:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>1. Functional groups get lowest possible numbers</li>
                <li>2. Multiple bonds (C=C, C≡C) get lowest numbers</li>
                <li>3. Substituents get lowest numbers overall</li>
                <li>4. When tied, alphabetical order of substituents decides</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Cyclic Compounds:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• Principal functional group gets position 1</li>
                <li>• Number clockwise or counterclockwise for lowest numbers</li>
                <li>• Benzene carbons are numbered 1-6 around the ring</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Substituent Naming */}
        <div className="p-6 bg-secondary/5 rounded-xl border border-secondary/20">
          <h3 className="text-xl font-semibold text-secondary mb-4">Substituent Naming Rules</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-foreground mb-2">Alkyl Groups:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• methyl (-CH₃), ethyl (-C₂H₅)</li>
                <li>• propyl (-C₃H₇), butyl (-C₄H₉)</li>
                <li>• isopropyl, isobutyl, sec-butyl, tert-butyl</li>
              </ul>
              
              <h4 className="font-semibold text-foreground mb-2 mt-4">Halogen Groups:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• fluoro (F), chloro (Cl)</li>
                <li>• bromo (Br), iodo (I)</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-2">Other Common Groups:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• nitro (-NO₂), amino (-NH₂)</li>
                <li>• hydroxy (-OH) → becomes -ol when principal</li>
                <li>• oxo (=O) → when ketone is substituent</li>
                <li>• phenyl (-C₆H₅) → benzene ring substituent</li>
              </ul>
              
              <h4 className="font-semibold text-foreground mb-2 mt-4">Multiplicity Prefixes:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• di- (2), tri- (3), tetra- (4)</li>
                <li>• penta- (5), hexa- (6), hepta- (7)</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Special Cases */}
        <div className="p-6 bg-muted/50 rounded-xl border border-border">
          <h3 className="text-xl font-semibold text-foreground mb-4">Special Cases & Exceptions</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-primary mb-2">Aromatic Compounds:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• Benzene derivatives: use ortho-, meta-, para- or number positions</li>
                <li>• Common names: toluene (methylbenzene), aniline (aminobenzene)</li>
                <li>• Phenol (hydroxybenzene), benzoic acid (benzenecarboxylic acid)</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-primary mb-2">Stereochemistry:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• E/Z notation for alkene stereoisomers</li>
                <li>• R/S notation for chiral centers</li>
                <li>• cis/trans for cyclic compounds</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-primary mb-2">Complex Substituents:</h4>
              <ul className="space-y-1 text-muted-foreground text-sm pl-4">
                <li>• Name complex substituents in parentheses</li>
                <li>• Use bis-, tris-, tetrakis- for identical complex groups</li>
                <li>• Alphabetize ignoring multiplicity prefixes</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Quick Reference */}
        <div className="p-6 bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl border border-primary/20">
          <h3 className="text-xl font-semibold text-primary mb-4">Quick Reference - Common Suffixes</h3>
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="font-semibold text-foreground mb-2">Hydrocarbons:</div>
              <ul className="space-y-1 text-muted-foreground">
                <li>Alkane: -ane</li>
                <li>Alkene: -ene</li>
                <li>Alkyne: -yne</li>
              </ul>
            </div>
            
            <div>
              <div className="font-semibold text-foreground mb-2">Oxygen Groups:</div>
              <ul className="space-y-1 text-muted-foreground">
                <li>Alcohol: -ol</li>
                <li>Aldehyde: -al</li>
                <li>Ketone: -one</li>
                <li>Carboxylic acid: -oic acid</li>
              </ul>
            </div>
            
            <div>
              <div className="font-semibold text-foreground mb-2">Nitrogen Groups:</div>
              <ul className="space-y-1 text-muted-foreground">
                <li>Amine: -amine</li>
                <li>Amide: -amide</li>
                <li>Nitrile: -nitrile</li>
              </ul>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.section>
  );
};

export default RulesSection;