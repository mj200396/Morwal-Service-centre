import { motion } from "framer-motion";
import { Atom, ChevronRight, Book, FlaskConical } from "lucide-react";
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface CompoundFamily {
  id: string;
  name: string;
  generalFormula: string;
  functionalGroup: string;
  suffix: string;
  examples: Array<{
    name: string;
    formula: string;
    structure: string;
  }>;
  description: string;
  difficulty: "easy" | "medium" | "hard";
}

const compoundFamilies: CompoundFamily[] = [
  {
    id: "alkanes",
    name: "Alkanes",
    generalFormula: "CₙH₂ₙ₊₂",
    functionalGroup: "None (only C-C and C-H bonds)",
    suffix: "-ane",
    examples: [
      { name: "Methane", formula: "CH₄", structure: "CH₄" },
      { name: "Ethane", formula: "C₂H₆", structure: "CH₃-CH₃" },
      { name: "Propane", formula: "C₃H₈", structure: "CH₃-CH₂-CH₃" },
      { name: "Butane", formula: "C₄H₁₀", structure: "CH₃-CH₂-CH₂-CH₃" }
    ],
    description: "Saturated hydrocarbons with only single bonds between carbon atoms.",
    difficulty: "easy"
  },
  {
    id: "alkenes",
    name: "Alkenes",
    generalFormula: "CₙH₂ₙ",
    functionalGroup: "C=C (double bond)",
    suffix: "-ene",
    examples: [
      { name: "Ethene", formula: "C₂H₄", structure: "CH₂=CH₂" },
      { name: "Propene", formula: "C₃H₆", structure: "CH₃-CH=CH₂" },
      { name: "But-1-ene", formula: "C₄H₈", structure: "CH₃-CH₂-CH=CH₂" },
      { name: "But-2-ene", formula: "C₄H₈", structure: "CH₃-CH=CH-CH₃" }
    ],
    description: "Unsaturated hydrocarbons containing one or more C=C double bonds.",
    difficulty: "medium"
  },
  {
    id: "alkynes",
    name: "Alkynes",
    generalFormula: "CₙH₂ₙ₋₂",
    functionalGroup: "C≡C (triple bond)",
    suffix: "-yne",
    examples: [
      { name: "Ethyne", formula: "C₂H₂", structure: "CH≡CH" },
      { name: "Propyne", formula: "C₃H₄", structure: "CH₃-C≡CH" },
      { name: "But-1-yne", formula: "C₄H₆", structure: "CH₃-CH₂-C≡CH" },
      { name: "But-2-yne", formula: "C₄H₆", structure: "CH₃-C≡C-CH₃" }
    ],
    description: "Unsaturated hydrocarbons containing one or more C≡C triple bonds.",
    difficulty: "medium"
  },
  {
    id: "alcohols",
    name: "Alcohols",
    generalFormula: "R-OH",
    functionalGroup: "-OH (hydroxyl group)",
    suffix: "-ol",
    examples: [
      { name: "Methanol", formula: "CH₄O", structure: "CH₃-OH" },
      { name: "Ethanol", formula: "C₂H₆O", structure: "CH₃-CH₂-OH" },
      { name: "Propan-1-ol", formula: "C₃H₈O", structure: "CH₃-CH₂-CH₂-OH" },
      { name: "Propan-2-ol", formula: "C₃H₈O", structure: "CH₃-CH(OH)-CH₃" }
    ],
    description: "Organic compounds containing one or more hydroxyl (-OH) functional groups.",
    difficulty: "easy"
  },
  {
    id: "aldehydes",
    name: "Aldehydes",
    generalFormula: "R-CHO",
    functionalGroup: "-CHO (carbonyl group)",
    suffix: "-al",
    examples: [
      { name: "Methanal", formula: "CH₂O", structure: "H-CHO" },
      { name: "Ethanal", formula: "C₂H₄O", structure: "CH₃-CHO" },
      { name: "Propanal", formula: "C₃H₆O", structure: "CH₃-CH₂-CHO" },
      { name: "Butanal", formula: "C₄H₈O", structure: "CH₃-CH₂-CH₂-CHO" }
    ],
    description: "Organic compounds containing a carbonyl group (C=O) at the end of the carbon chain.",
    difficulty: "medium"
  },
  {
    id: "ketones",
    name: "Ketones",
    generalFormula: "R-CO-R'",
    functionalGroup: "C=O (carbonyl group)",
    suffix: "-one",
    examples: [
      { name: "Propanone", formula: "C₃H₆O", structure: "CH₃-CO-CH₃" },
      { name: "Butanone", formula: "C₄H₈O", structure: "CH₃-CO-CH₂-CH₃" },
      { name: "Pentan-2-one", formula: "C₅H₁₀O", structure: "CH₃-CO-CH₂-CH₂-CH₃" },
      { name: "Pentan-3-one", formula: "C₅H₁₀O", structure: "CH₃-CH₂-CO-CH₂-CH₃" }
    ],
    description: "Organic compounds containing a carbonyl group (C=O) within the carbon chain.",
    difficulty: "medium"
  },
  {
    id: "carboxylic-acids",
    name: "Carboxylic Acids",
    generalFormula: "R-COOH",
    functionalGroup: "-COOH (carboxyl group)",
    suffix: "-oic acid",
    examples: [
      { name: "Methanoic acid", formula: "CH₂O₂", structure: "H-COOH" },
      { name: "Ethanoic acid", formula: "C₂H₄O₂", structure: "CH₃-COOH" },
      { name: "Propanoic acid", formula: "C₃H₆O₂", structure: "CH₃-CH₂-COOH" },
      { name: "Butanoic acid", formula: "C₄H₈O₂", structure: "CH₃-CH₂-CH₂-COOH" }
    ],
    description: "Organic compounds containing a carboxyl group (-COOH) at the end of the carbon chain.",
    difficulty: "medium"
  },
  {
    id: "aromatic",
    name: "Aromatic Compounds",
    generalFormula: "C₆H₆ (benzene)",
    functionalGroup: "Benzene ring",
    suffix: "benzene / phenyl-",
    examples: [
      { name: "Benzene", formula: "C₆H₆", structure: "⬢" },
      { name: "Methylbenzene", formula: "C₇H₈", structure: "⬢-CH₃" },
      { name: "Phenol", formula: "C₆H₆O", structure: "⬢-OH" },
      { name: "Benzoic acid", formula: "C₇H₆O₂", structure: "⬢-COOH" }
    ],
    description: "Compounds containing benzene rings with delocalized electrons.",
    difficulty: "hard"
  }
];

const CompoundsSection = () => {
  const [selectedFamily, setSelectedFamily] = useState<string | null>(null);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-success/20 text-success border-success/30';
      case 'medium': return 'bg-warning/20 text-warning border-warning/30';
      case 'hard': return 'bg-destructive/20 text-destructive border-destructive/30';
      default: return 'bg-muted/20 text-muted-foreground border-muted/30';
    }
  };

  return (
    <motion.section
      className="chemistry-card"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="flex items-center gap-4 mb-6"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <Atom className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold text-foreground">Compound Families</h2>
      </motion.div>

      <motion.p
        className="text-lg text-muted-foreground mb-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        Explore the naming conventions for different families of organic compounds.
      </motion.p>

      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        {compoundFamilies.map((family, index) => (
          <motion.div
            key={family.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 + index * 0.1 }}
          >
            <Card 
              className="cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-border/50 hover:border-primary/30"
              onClick={() => setSelectedFamily(selectedFamily === family.id ? null : family.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-foreground">{family.name}</CardTitle>
                  <Badge className={`text-xs ${getDifficultyColor(family.difficulty)}`}>
                    {family.difficulty}
                  </Badge>
                </div>
                <CardDescription className="text-sm font-mono text-primary">
                  {family.generalFormula}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="font-semibold text-foreground">Functional Group:</span>
                    <br />
                    <span className="text-muted-foreground">{family.functionalGroup}</span>
                  </div>
                  <div className="text-sm">
                    <span className="font-semibold text-foreground">Suffix:</span> 
                    <span className="ml-2 font-mono text-primary">{family.suffix}</span>
                  </div>
                  {selectedFamily === family.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 pt-4 border-t border-border/50"
                    >
                      <p className="text-sm text-muted-foreground mb-3">
                        {family.description}
                      </p>
                      <div className="space-y-2">
                        <h4 className="text-sm font-semibold text-foreground">Examples:</h4>
                        {family.examples.map((example, idx) => (
                          <div key={idx} className="text-xs bg-muted/30 rounded-lg p-2">
                            <div className="font-semibold text-foreground">{example.name}</div>
                            <div className="font-mono text-primary">{example.formula}</div>
                            <div className="font-mono text-muted-foreground">{example.structure}</div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      <motion.div
        className="mt-8 p-6 bg-primary/5 rounded-xl border border-primary/20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <div className="flex items-center gap-3 mb-4">
          <FlaskConical className="h-6 w-6 text-primary" />
          <h3 className="text-xl font-semibold text-primary">Quick Reference</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="font-semibold text-foreground mb-2">Priority Order (Highest to Lowest):</h4>
            <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
              <li>Carboxylic acids (-COOH)</li>
              <li>Aldehydes (-CHO)</li>
              <li>Ketones (C=O)</li>
              <li>Alcohols (-OH)</li>
              <li>Alkenes (C=C)</li>
              <li>Alkynes (C≡C)</li>
            </ol>
          </div>
          <div>
            <h4 className="font-semibold text-foreground mb-2">Common Prefixes:</h4>
            <ul className="space-y-1 text-muted-foreground">
              <li><span className="font-mono">meth-</span> = 1 carbon</li>
              <li><span className="font-mono">eth-</span> = 2 carbons</li>
              <li><span className="font-mono">prop-</span> = 3 carbons</li>
              <li><span className="font-mono">but-</span> = 4 carbons</li>
              <li><span className="font-mono">pent-</span> = 5 carbons</li>
              <li><span className="font-mono">hex-</span> = 6 carbons</li>
            </ul>
          </div>
        </div>
      </motion.div>
    </motion.section>
  );
};

export default CompoundsSection;