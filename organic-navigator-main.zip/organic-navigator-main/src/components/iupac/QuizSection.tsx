import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { HelpCircle, CheckCircle, XCircle, RotateCcw, ArrowRight } from "lucide-react";

interface QuizQuestion {
  question: string;
  svg?: string;
  isStructureQuestion?: boolean;
  options: string[];
  answer: number;
  explanation: string;
}

const quizQuestions: QuizQuestion[] = [
  {
    question: "What is the correct IUPAC name for this compound?",
    svg: `
      <svg viewBox="0 0 300 150" className="w-full h-auto">
        <path stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" 
              d="M50 75 L100 100 L150 75 L200 100 L250 75"/>
        <line stroke="hsl(var(--molecule-carbon))" strokeWidth="4" 
              x1="100" y1="100" x2="100" y2="135"/>
      </svg>
    `,
    options: ["2-methylhexane", "5-methylhexane", "2-methylpentane", "isohexane"],
    answer: 2,
    explanation: "The longest chain has 5 carbons (pentane). Number from the left to give the methyl substituent the lowest locant (2)."
  },
  {
    question: "Which functional group has the highest priority?",
    options: ["Alcohol (-OH)", "Ketone (C=O)", "Carboxylic Acid (-COOH)", "Alkene (C=C)"],
    answer: 2,
    explanation: "Carboxylic acids have the highest priority among these functional groups and will determine the suffix."
  },
  {
    question: "What is the correct suffix for an alcohol?",
    options: ["-ane", "-ol", "-one", "-al"],
    answer: 1,
    explanation: "Alcohols use the suffix '-ol' in IUPAC nomenclature."
  }
];

const QuizSection = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState<boolean[]>(new Array(quizQuestions.length).fill(false));

  const currentQuestion = quizQuestions[currentQuestionIndex];

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResult) return;
    
    setSelectedAnswer(answerIndex);
    setShowResult(true);
    
    const newAnswered = [...answered];
    if (!newAnswered[currentQuestionIndex]) {
      newAnswered[currentQuestionIndex] = true;
      setAnswered(newAnswered);
      
      if (answerIndex === currentQuestion.answer) {
        setScore(score + 1);
      }
    }
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < quizQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnswered(new Array(quizQuestions.length).fill(false));
  };

  const isQuizComplete = currentQuestionIndex === quizQuestions.length - 1 && showResult;

  return (
    <motion.section
      className="chemistry-card"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="flex items-center gap-4 mb-6"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <HelpCircle className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold text-foreground">Test Your Knowledge</h2>
      </motion.div>

      <motion.div
        className="max-w-4xl mx-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-muted-foreground">
              Question {currentQuestionIndex + 1} of {quizQuestions.length}
            </span>
            <span className="text-sm text-muted-foreground">
              Score: {score}/{answered.filter(Boolean).length}
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <motion.div
              className="bg-primary h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${((currentQuestionIndex + 1) / quizQuestions.length) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestionIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <div className="chemistry-card bg-primary/5 border-primary/20 mb-8">
              <h3 className="text-xl font-semibold text-center mb-6 text-foreground">
                {currentQuestion.question}
              </h3>
              
              {currentQuestion.svg && (
                <div className="molecule-viewer mb-6" dangerouslySetInnerHTML={{ __html: currentQuestion.svg }} />
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {currentQuestion.options.map((option, index) => {
                let className = "quiz-option text-left";
                
                if (showResult) {
                  if (index === currentQuestion.answer) {
                    className += " correct";
                  } else if (index === selectedAnswer && selectedAnswer !== currentQuestion.answer) {
                    className += " incorrect";
                  }
                }

                return (
                  <motion.button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    className={className}
                    disabled={showResult}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * index }}
                    whileHover={!showResult ? { scale: 1.02, y: -2 } : {}}
                    whileTap={!showResult ? { scale: 0.98 } : {}}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        showResult && index === currentQuestion.answer 
                          ? 'border-success bg-success'
                          : showResult && index === selectedAnswer && selectedAnswer !== currentQuestion.answer
                          ? 'border-destructive bg-destructive'
                          : 'border-muted-foreground'
                      }`}>
                        {showResult && index === currentQuestion.answer && (
                          <CheckCircle className="h-4 w-4 text-white" />
                        )}
                        {showResult && index === selectedAnswer && selectedAnswer !== currentQuestion.answer && (
                          <XCircle className="h-4 w-4 text-white" />
                        )}
                      </div>
                      <span className="font-semibold">{option}</span>
                    </div>
                  </motion.button>
                );
              })}
            </div>

            <AnimatePresence>
              {showResult && (
                <motion.div
                  className={`p-6 rounded-xl mb-6 ${
                    selectedAnswer === currentQuestion.answer
                      ? 'bg-success/10 border border-success/20'
                      : 'bg-destructive/10 border border-destructive/20'
                  }`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="flex items-start gap-3">
                    {selectedAnswer === currentQuestion.answer ? (
                      <CheckCircle className="h-6 w-6 text-success mt-1 flex-shrink-0" />
                    ) : (
                      <XCircle className="h-6 w-6 text-destructive mt-1 flex-shrink-0" />
                    )}
                    <div>
                      <h4 className="font-bold mb-2">
                        {selectedAnswer === currentQuestion.answer ? 'Correct!' : 'Incorrect.'}
                      </h4>
                      <p className="text-sm">{currentQuestion.explanation}</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </AnimatePresence>

        <div className="text-center space-y-4">
          {isQuizComplete ? (
            <motion.div
              className="space-y-4"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="chemistry-card bg-primary/10 border-primary/20">
                <h3 className="text-2xl font-bold text-primary mb-2">Quiz Complete!</h3>
                <p className="text-xl text-foreground">
                  Final Score: {score} out of {quizQuestions.length}
                </p>
                <p className="text-muted-foreground mt-2">
                  {score === quizQuestions.length ? "Perfect! You're a naming expert!" :
                   score >= quizQuestions.length * 0.7 ? "Great job! You have a solid understanding." :
                   "Keep practicing! Review the concepts and try again."}
                </p>
              </div>
              
              <motion.button
                onClick={restartQuiz}
                className="btn-chemistry flex items-center gap-2 mx-auto"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <RotateCcw className="h-4 w-4" />
                Restart Quiz
              </motion.button>
            </motion.div>
          ) : (
            showResult && (
              <motion.button
                onClick={nextQuestion}
                className="btn-chemistry flex items-center gap-2 mx-auto"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Next Question
                <ArrowRight className="h-4 w-4" />
              </motion.button>
            )
          )}
        </div>
      </motion.div>
    </motion.section>
  );
};

export default QuizSection;