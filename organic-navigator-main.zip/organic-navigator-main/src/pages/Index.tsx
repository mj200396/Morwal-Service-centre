import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Atom, 
  BookOpen, 
  FlaskConical, 
  GraduationCap, 
  ChevronRight,
  Sparkles
} from "lucide-react";
import Header from "@/components/iupac/Header";
import TabNavigation from "@/components/iupac/TabNavigation";
import IntroductionSection from "@/components/iupac/IntroductionSection";
import NamingRulesSection from "@/components/iupac/NamingRulesSection";
import CompoundsSection from "@/components/iupac/CompoundsSection";
import PracticeSection from "@/components/iupac/PracticeSection";
import FunctionalGroupsTable from "@/components/iupac/FunctionalGroupsTable";
import RulesSection from "@/components/iupac/RulesSection";
import QuizSection from "@/components/iupac/QuizSection";

const tabs = [
  { id: 'introduction', label: 'Introduction', icon: BookOpen },
  { id: 'rules', label: 'Naming Rules', icon: FlaskConical },
  { id: 'compounds', label: 'Compounds', icon: Atom },
  { id: 'practice', label: 'Practice', icon: GraduationCap },
  { id: 'groups', label: 'Groups', icon: ChevronRight },
  { id: 'notes', label: 'Rules', icon: Sparkles },
  { id: 'quiz', label: 'Quiz', icon: GraduationCap },
];

const Index = () => {
  const [activeTab, setActiveTab] = useState('introduction');

  const renderContent = () => {
    switch (activeTab) {
      case 'introduction':
        return <IntroductionSection />;
      case 'rules':
        return <NamingRulesSection />;
      case 'compounds':
        return <CompoundsSection />;
      case 'practice':
        return <PracticeSection />;
      case 'groups':
        return <FunctionalGroupsTable />;
      case 'notes':
        return <RulesSection />;
      case 'quiz':
        return <QuizSection />;
      default:
        return <IntroductionSection />;
    }
  };

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <Header />
        
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <TabNavigation
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        </motion.div>

        <motion.main
          className="mt-8"
          layout
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </motion.main>
      </div>
    </div>
  );
};

export default Index;