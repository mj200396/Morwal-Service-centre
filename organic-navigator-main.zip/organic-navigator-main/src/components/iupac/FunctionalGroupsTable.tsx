import { motion } from "framer-motion";
import { Table, HelpCircle } from "lucide-react";
import { useState } from "react";

interface FunctionalGroup {
  priority: number;
  class: string;
  formula: string;
  suffix: string;
  prefix: string;
  example: string;
}

const functionalGroups: FunctionalGroup[] = [
  {
    priority: 1,
    class: 'Carboxylic Acid',
    formula: '-COOH',
    suffix: '-oic acid',
    prefix: 'carboxy-',
    example: 'Ethanoic acid (acetic acid) is the main component of vinegar.'
  },
  {
    priority: 2,
    class: 'Ester',
    formula: '-COOR',
    suffix: '-oate',
    prefix: 'alkoxycarbonyl-',
    example: 'Ethyl acetate is a common solvent in nail polish remover.'
  },
  {
    priority: 3,
    class: 'Aldehyde',
    formula: '-CHO',
    suffix: '-al',
    prefix: 'formyl- or oxo-',
    example: 'Formaldehyde is used as a preservative and disinfectant.'
  },
  {
    priority: 4,
    class: 'Ketone',
    formula: '-C(O)-',
    suffix: '-one',
    prefix: 'oxo-',
    example: 'Acetone (propanone) is a powerful solvent used in cleaners.'
  },
  {
    priority: 5,
    class: 'Alcohol',
    formula: '-OH',
    suffix: '-ol',
    prefix: 'hydroxy-',
    example: 'Ethanol is the alcohol in beverages and hand sanitizers.'
  },
  {
    priority: 6,
    class: 'Amine',
    formula: '-NH₂',
    suffix: '-amine',
    prefix: 'amino-',
    example: 'Amino acids are the building blocks of proteins.'
  },
  {
    priority: 7,
    class: 'Alkene',
    formula: 'C=C',
    suffix: '-ene',
    prefix: 'alkenyl-',
    example: 'Ethene is used to produce polyethylene plastic.'
  },
  {
    priority: 8,
    class: 'Alkyne',
    formula: 'C≡C',
    suffix: '-yne',
    prefix: 'alkynyl-',
    example: 'Acetylene (ethyne) is used in welding torches.'
  },
  {
    priority: 9,
    class: 'Haloalkane',
    formula: '-X',
    suffix: 'N/A',
    prefix: 'halo-',
    example: 'Chloroform was one of the first anesthetics.'
  }
];

const FunctionalGroupsTable = () => {
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  return (
    <motion.section
      className="chemistry-card"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="flex items-center gap-4 mb-6"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <Table className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold text-foreground">Functional Group Priority</h2>
      </motion.div>

      <motion.div
        className="overflow-x-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-muted/50">
              <th className="p-4 text-center font-semibold border-b-2 border-border">Priority</th>
              <th className="p-4 text-left font-semibold border-b-2 border-border">Class</th>
              <th className="p-4 text-left font-semibold border-b-2 border-border">Formula</th>
              <th className="p-4 text-left font-semibold border-b-2 border-border">Suffix</th>
              <th className="p-4 text-left font-semibold border-b-2 border-border">Prefix</th>
              <th className="p-4 text-center font-semibold border-b-2 border-border">
                <HelpCircle className="h-4 w-4 mx-auto" />
              </th>
            </tr>
          </thead>
          <tbody>
            {functionalGroups.map((fg, index) => (
              <motion.tr
                key={fg.priority}
                className={`border-b border-border transition-colors duration-200 ${
                  hoveredRow === index ? 'bg-primary/5' : 'hover:bg-muted/30'
                }`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + index * 0.05 }}
                onMouseEnter={() => setHoveredRow(index)}
                onMouseLeave={() => setHoveredRow(null)}
              >
                <td className="p-4 text-center">
                  <motion.div
                    className="inline-flex items-center justify-center h-8 w-8 bg-primary/20 text-primary rounded-full font-bold"
                    whileHover={{ scale: 1.1 }}
                  >
                    {fg.priority}
                  </motion.div>
                </td>
                <td className="p-4 font-semibold text-foreground">{fg.class}</td>
                <td className="p-4 font-mono text-muted-foreground">{fg.formula}</td>
                <td className="p-4 font-semibold text-primary">{fg.suffix}</td>
                <td className="p-4 font-semibold text-secondary">{fg.prefix}</td>
                <td className="p-4 text-center">
                  <motion.div
                    className="relative group"
                    whileHover={{ scale: 1.1 }}
                  >
                    <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-foreground text-background text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10 w-64 pointer-events-none">
                      {fg.example}
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-foreground"></div>
                    </div>
                  </motion.div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </motion.div>

      <motion.div
        className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-primary">Priority Rule:</span> When multiple functional groups are present, 
          the one with the highest priority (lowest number) becomes the suffix, while others become prefixes.
        </p>
      </motion.div>
    </motion.section>
  );
};

export default FunctionalGroupsTable;