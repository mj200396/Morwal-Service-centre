import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FlaskConical, Play, RotateCcw, ChevronLeft, ChevronRight, Shuffle, Atom } from "lucide-react";
import MoleculeViewer from "./MoleculeViewer";

interface NamingExample {
  id: number;
  name: string;
  description: string;
  difficulty: "easy" | "medium" | "hard";
  category: string;
  molecularFormula: string;
  svg: string;
  locants: Array<{ x: number; y: number; label: string }>;
  steps: Array<{
    title: string;
    description: string;
    result: string;
    highlight: "chain" | "substituent" | "functional" | "locants" | "none";
    color: string;
  }>;
}

const namingExamples: NamingExample[] = [
  {
    id: 1,
    name: "3-methylhexan-1-ol",
    description: "Alcohol with methyl substituent",
    difficulty: "medium",
    category: "Alcohols",
    molecularFormula: "C₇H₁₆O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100 L250 75 L300 100"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="150" y1="75" x2="150" y2="40"/>
          <line id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="50" y1="75" x2="20" y2="90"/>
          <text x="5" y="95" fontSize="16" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" },
      { x: 295, y: 120, label: "6" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest continuous carbon chain containing the principal functional group has 6 carbons.",
        result: "Root name: hex-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Start numbering from the end that gives the functional group (-OH) the lowest possible number.",
        result: "C1 is the carbon with the -OH group",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "A one-carbon group (-CH₃) is on position 3.",
        result: "Prefix: 3-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Identify Functional Group",
        description: "The -OH group (alcohol) is the highest priority functional group.",
        result: "Suffix: -an-1-ol",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 2,
    name: "2-methylbutane",
    description: "Simple alkane with methyl branch",
    difficulty: "easy",
    category: "Alkanes",
    molecularFormula: "C₅H₁₂",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest continuous carbon chain has 4 carbons.",
        result: "Root name: but-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the substituent the lowest possible number.",
        result: "Numbering from left: 1-2-3-4",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "A methyl group (-CH₃) is on position 2.",
        result: "Prefix: 2-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Add Suffix",
        description: "Alkane suffix with no functional groups.",
        result: "Suffix: -ane",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 3,
    name: "pentan-2-one",
    description: "Ketone with 5-carbon chain",
    difficulty: "medium",
    category: "Ketones",
    molecularFormula: "C₅H₁₀O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100 L250 75"/>
          <circle cx="100" cy="100" r="8" fill="hsl(var(--functional-group))" stroke="hsl(var(--molecule-carbon))" strokeWidth="3"/>
          <text x="85" y="130" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest carbon chain has 5 carbons.",
        result: "Root name: pent-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the carbonyl group the lowest number.",
        result: "Carbonyl at position 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Ketone group (C=O) is the principal functional group.",
        result: "Suffix: -an-2-one",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Substituents",
        description: "No other substituents present.",
        result: "Final name: pentan-2-one",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 4,
    name: "3-ethylheptane",
    description: "Alkane with ethyl substituent",
    difficulty: "medium",
    category: "Alkanes",
    molecularFormula: "C₉H₂₀",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100 L250 75 L300 100 L350 75"/>
          <path id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M150 75 L150 40 L190 25"/>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" },
      { x: 295, y: 120, label: "6" },
      { x: 345, y: 65, label: "7" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest continuous carbon chain has 7 carbons.",
        result: "Root name: hept-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give substituents the lowest possible numbers.",
        result: "Ethyl group at position 3",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "A two-carbon group (ethyl) is on position 3.",
        result: "Prefix: 3-ethyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Add Suffix",
        description: "Alkane suffix with no functional groups.",
        result: "Suffix: -ane",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 5,
    name: "butan-1-ol",
    description: "Primary alcohol",
    difficulty: "easy",
    category: "Alcohols",
    molecularFormula: "C₄H₁₀O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100"/>
          <line id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="50" y1="75" x2="20" y2="60"/>
          <text x="5" y="60" fontSize="16" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest carbon chain has 4 carbons.",
        result: "Root name: but-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the -OH group the lowest number.",
        result: "OH at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Primary alcohol (-OH) is the functional group.",
        result: "Suffix: -an-1-ol",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Substituents",
        description: "No other substituents present.",
        result: "Final name: butan-1-ol",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 6,
    name: "2,3-dimethylpentane",
    description: "Alkane with two methyl groups",
    difficulty: "medium",
    category: "Alkanes",
    molecularFormula: "C₇H₁₆",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100 L250 75"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="150" y1="75" x2="150" y2="40"/>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest carbon chain has 5 carbons.",
        result: "Root name: pent-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give substituents the lowest numbers.",
        result: "Methyl groups at positions 2 and 3",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "Two methyl groups at positions 2 and 3.",
        result: "Prefix: 2,3-dimethyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Add Suffix",
        description: "Alkane suffix with no functional groups.",
        result: "Suffix: -ane",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 7,
    name: "hexanal",
    description: "Aldehyde with 6-carbon chain",
    difficulty: "easy",
    category: "Aldehydes",
    molecularFormula: "C₆H₁₂O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100 L250 75 L300 100"/>
          <circle cx="50" cy="75" r="8" fill="hsl(var(--functional-group))" stroke="hsl(var(--molecule-carbon))" strokeWidth="3"/>
          <text x="30" y="60" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="20" y="100" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">H</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" },
      { x: 295, y: 120, label: "6" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest carbon chain including aldehyde has 6 carbons.",
        result: "Root name: hex-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Aldehyde carbon is always position 1.",
        result: "CHO at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Aldehyde group (-CHO) is the functional group.",
        result: "Suffix: -al",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Substituents",
        description: "No other substituents present.",
        result: "Final name: hexanal",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 8,
    name: "propan-2-ol",
    description: "Secondary alcohol (isopropanol)",
    difficulty: "easy",
    category: "Alcohols",
    molecularFormula: "C₃H₈O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75"/>
          <line id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>
          <text x="85" y="150" fontSize="16" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest carbon chain has 3 carbons.",
        result: "Root name: prop-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the -OH group the lowest number.",
        result: "OH at position 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Secondary alcohol (-OH) is the functional group.",
        result: "Suffix: -an-2-ol",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Substituents",
        description: "No other substituents present.",
        result: "Final name: propan-2-ol",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 9,
    name: "3-methylbutan-2-one",
    description: "Ketone with methyl substituent",
    difficulty: "medium",
    category: "Ketones",
    molecularFormula: "C₅H₁₀O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="150" y1="75" x2="150" y2="40"/>
          <circle cx="100" cy="100" r="8" fill="hsl(var(--functional-group))" stroke="hsl(var(--molecule-carbon))" strokeWidth="3"/>
          <text x="85" y="130" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest carbon chain has 4 carbons.",
        result: "Root name: but-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the carbonyl the lowest number.",
        result: "C=O at position 2, methyl at 3",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "Methyl group at position 3.",
        result: "Prefix: 3-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Identify Functional Group",
        description: "Ketone group (C=O) is the functional group.",
        result: "Suffix: -an-2-one",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 10,
    name: "2-methylpropanal",
    description: "Aldehyde with methyl substituent",
    difficulty: "medium",
    category: "Aldehydes",
    molecularFormula: "C₄H₈O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>
          <circle cx="50" cy="75" r="8" fill="hsl(var(--functional-group))" stroke="hsl(var(--molecule-carbon))" strokeWidth="3"/>
          <text x="30" y="60" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="20" y="100" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">H</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain including aldehyde has 3 carbons.",
        result: "Root name: prop-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Aldehyde carbon is always position 1.",
        result: "CHO at 1, methyl at 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "Methyl group at position 2.",
        result: "Prefix: 2-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Identify Functional Group",
        description: "Aldehyde group (-CHO) is the functional group.",
        result: "Suffix: -al",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  // Add 25 more comprehensive examples
  {
    id: 11,
    name: "cyclohexane",
    description: "Simple cyclic alkane",
    difficulty: "easy",
    category: "Cyclic Compounds",
    molecularFormula: "C₆H₁₂",
    svg: `<polygon id="chain" points="200,60 260,90 260,150 200,180 140,150 140,90" 
           stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>`,
    locants: [
      { x: 200, y: 50, label: "1" },
      { x: 270, y: 85, label: "2" },
      { x: 270, y: 155, label: "3" },
      { x: 200, y: 190, label: "4" },
      { x: 130, y: 155, label: "5" },
      { x: 130, y: 85, label: "6" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "A ring of 6 carbon atoms forms the base structure.",
        result: "Root name: cyclohex-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Count Ring Carbons",
        description: "The ring contains 6 carbons with no additional chains.",
        result: "Six-membered ring",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "No Substituents",
        description: "No substituents are attached to the ring.",
        result: "No prefixes needed",
        highlight: "none",
        color: "secondary"
      },
      {
        title: "Add Suffix",
        description: "Cyclic alkane with no functional groups.",
        result: "Suffix: -ane",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 12,
    name: "propanoic acid",
    description: "Simple carboxylic acid",
    difficulty: "easy",
    category: "Carboxylic Acids",
    molecularFormula: "C₃H₆O₂",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75"/>
          <circle cx="150" cy="75" r="8" fill="hsl(var(--functional-group))" stroke="hsl(var(--molecule-carbon))" strokeWidth="3"/>
          <line id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="150" y1="75" x2="180" y2="60"/>
          <text x="185" y="60" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>
          <text x="135" y="60" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 145, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 45, y: 65, label: "3" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain including carboxyl has 3 carbons.",
        result: "Root name: prop-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Carboxyl carbon is always position 1.",
        result: "COOH at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Carboxylic acid (-COOH) is the highest priority group.",
        result: "Suffix: -anoic acid",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Substituents",
        description: "No other substituents present.",
        result: "Final name: propanoic acid",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 13,
    name: "but-1-ene",
    description: "Terminal alkene",
    difficulty: "easy",
    category: "Alkenes",
    molecularFormula: "C₄H₈",
    svg: `<path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 80 L100 105"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 100 L150 75 L200 100"/>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain containing the double bond has 4 carbons.",
        result: "Root name: but-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the double bond the lowest number.",
        result: "C=C starts at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Double bond (C=C) determines the suffix.",
        result: "Suffix: -1-ene",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Substituents",
        description: "No other substituents present.",
        result: "Final name: but-1-ene",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 14,
    name: "ethyl acetate",
    description: "Common ester",
    difficulty: "medium",
    category: "Esters",
    molecularFormula: "C₄H₈O₂",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <circle cx="100" cy="100" r="8" fill="hsl(var(--functional-group))" stroke="hsl(var(--molecule-carbon))" strokeWidth="3"/>
          <line id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="140" y2="85"/>
          <path id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M140 85 L180 100"/>
          <text x="85" y="85" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="125" y="75" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" }
    ],
    steps: [
      {
        title: "Identify Ester Groups",
        description: "Ester formed from acetic acid and ethanol.",
        result: "Acetate + ethyl",
        highlight: "functional",
        color: "primary"
      },
      {
        title: "Name Alkyl Group",
        description: "Two-carbon chain attached to oxygen.",
        result: "Ethyl group",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Name Carboxylate",
        description: "Two-carbon carboxylate from acetic acid.",
        result: "Acetate group",
        highlight: "chain",
        color: "accent"
      },
      {
        title: "Combine Names",
        description: "Alkyl group first, then carboxylate.",
        result: "Final name: ethyl acetate",
        highlight: "none",
        color: "primary"
      }
    ]
  },
  {
    id: 15,
    name: "2-methylbut-2-ene",
    description: "Substituted internal alkene",
    difficulty: "medium",
    category: "Alkenes",
    molecularFormula: "C₅H₁₀",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 100 L150 75"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 105 L150 80"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M150 75 L200 100"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain containing the double bond has 4 carbons.",
        result: "Root name: but-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the double bond the lowest number.",
        result: "C=C at position 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "Methyl group at position 2.",
        result: "Prefix: 2-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Identify Functional Group",
        description: "Double bond determines the suffix.",
        result: "Suffix: -2-ene",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 16,
    name: "methylamine",
    description: "Primary amine",
    difficulty: "easy",
    category: "Amines",
    molecularFormula: "CH₅N",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 75 L140 60"/>
          <text x="145" y="60" fontSize="16" fontWeight="bold" fill="hsl(var(--functional-group))">NH₂</text>`,
    locants: [
      { x: 95, y: 65, label: "1" }
    ],
    steps: [
      {
        title: "Identify Base Structure",
        description: "One carbon chain with amino group.",
        result: "Root name: meth-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Primary amine (-NH₂) group present.",
        result: "Suffix: -amine",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Numbering Needed",
        description: "Only one carbon, no numbering required.",
        result: "No locants needed",
        highlight: "none",
        color: "secondary"
      },
      {
        title: "Simple Naming",
        description: "Combine root with amine suffix.",
        result: "Final name: methylamine",
        highlight: "none",
        color: "primary"
      }
    ]
  },
  {
    id: 17,
    name: "propyne",
    description: "Terminal alkyne",
    difficulty: "easy",
    category: "Alkynes",
    molecularFormula: "C₃H₄",
    svg: `<path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 78 L100 103"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 72 L100 97"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 100 L150 75"/>
          <text x="20" y="70" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">H</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain containing the triple bond has 3 carbons.",
        result: "Root name: prop-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the triple bond the lowest number.",
        result: "C≡C starts at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Triple bond (C≡C) determines the suffix.",
        result: "Suffix: -yne",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Terminal Alkyne",
        description: "Position 1 is implied for terminal alkynes.",
        result: "Final name: propyne",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 18,
    name: "cyclohexanol",
    description: "Cyclic alcohol",
    difficulty: "medium",
    category: "Cyclic Compounds",
    molecularFormula: "C₆H₁₂O",
    svg: `<polygon id="chain" points="200,70 260,100 260,160 200,190 140,160 140,100" 
           stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="70" x2="200" y2="40"/>
          <text x="185" y="35" fontSize="16" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [
      { x: 200, y: 60, label: "1" },
      { x: 270, y: 95, label: "2" },
      { x: 270, y: 165, label: "3" },
      { x: 200, y: 200, label: "4" },
      { x: 130, y: 165, label: "5" },
      { x: 130, y: 95, label: "6" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "Six-membered carbon ring with OH group.",
        result: "Root name: cyclohex-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Ring",
        description: "OH group gets position 1 by convention.",
        result: "OH at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Alcohol (-OH) is the functional group.",
        result: "Suffix: -anol",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Cyclic Alcohol Naming",
        description: "Combine cyclic root with alcohol suffix.",
        result: "Final name: cyclohexanol",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 19,
    name: "2-chloropropane",
    description: "Haloalkane with chlorine",
    difficulty: "easy",
    category: "Haloalkanes",
    molecularFormula: "C₃H₇Cl",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>
          <text x="85" y="150" fontSize="16" fontWeight="bold" fill="hsl(var(--substituent-highlight))">Cl</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest carbon chain has 3 carbons.",
        result: "Root name: prop-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give substituents the lowest number.",
        result: "Chlorine at position 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Halogen Substituent",
        description: "Chlorine substituent at position 2.",
        result: "Prefix: 2-chloro",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Add Alkane Suffix",
        description: "No functional groups, alkane suffix.",
        result: "Suffix: -ane",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 20,
    name: "ethanoic acid",
    description: "Simple carboxylic acid",
    difficulty: "easy",
    category: "Carboxylic Acids",
    molecularFormula: "C₂H₄O₂",
    svg: `<!-- Two-carbon chain with carboxyl group -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 100"/>
          <!-- Carboxyl group at position 1 -->
          <circle cx="100" cy="100" r="8" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="100" x2="135" y2="85"/>
          <text x="125" y="80" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>
          <text x="85" y="85" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 95, y: 120, label: "1" },
      { x: 45, y: 120, label: "2" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain including carboxyl has 2 carbons.",
        result: "Root name: ethan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Carboxyl carbon must be position 1 (IUPAC rule).",
        result: "COOH at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Carboxylic acid is the principal group.",
        result: "Suffix: -oic acid",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Complete Name",
        description: "Combine root with carboxylic acid suffix.",
        result: "Final name: ethanoic acid",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 21,
    name: "benzoic acid",
    description: "Aromatic carboxylic acid",
    difficulty: "medium",
    category: "Aromatic Compounds",
    molecularFormula: "C₇H₆O₂",
    svg: `<!-- Benzene ring with IIT JEE standard hexagonal structure -->
          <polygon id="chain" points="200,50 250,75 250,125 200,150 150,125 150,75" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Alternating double bonds in benzene ring (IIT JEE standard) -->
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="215" y1="62" x2="235" y2="80"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="235" y1="120" x2="215" y2="138"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="185" y1="138" x2="165" y2="120"/>
          <!-- Carboxyl group -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="50" x2="200" y2="15"/>
          <circle cx="200" cy="22" r="5" fill="hsl(var(--functional-group))"/>
          <text x="175" y="12" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">COOH</text>`,
     locants: [
       { x: 200, y: 30, label: "1" },
       { x: 260, y: 70, label: "2" },
       { x: 260, y: 130, label: "3" },
       { x: 200, y: 160, label: "4" },
       { x: 140, y: 130, label: "5" },
       { x: 140, y: 70, label: "6" }
    ],
    steps: [
      {
        title: "Identify Aromatic Ring",
        description: "Benzene ring with carboxyl substitution.",
        result: "Base name: benzene",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Locate Functional Group",
        description: "Carboxylic acid group attached to benzene.",
        result: "COOH at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Apply Aromatic Naming",
        description: "Benzene + carboxylic acid = benzoic acid.",
        result: "Aromatic acid naming",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Special Name",
        description: "Common name used for benzenecarboxylic acid.",
        result: "Final name: benzoic acid",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 22,
    name: "N-methylpropylamine",
    description: "Secondary amine",
    difficulty: "medium",
    category: "Amines",
    molecularFormula: "C₄H₁₁N",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75"/>
          <line id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="135" x2="70" y2="150"/>
          <text x="85" y="130" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">N</text>
          <text x="50" y="160" fontSize="12" fontWeight="bold" fill="hsl(var(--substituent-highlight))">CH₃</text>
          <text x="115" y="145" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">H</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" }
    ],
    steps: [
      {
        title: "Identify Longest Chain",
        description: "Longest carbon chain has 3 carbons.",
        result: "Base name: propyl",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Locate Amine Group",
        description: "Secondary amine with nitrogen attached.",
        result: "NH group present",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Name N-Substituent",
        description: "Methyl group attached to nitrogen.",
        result: "N-methyl substitution",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Combine Components",
        description: "N-alkyl + alkyl + amine naming pattern.",
        result: "Final name: N-methylpropylamine",
        highlight: "none",
        color: "primary"
      }
    ]
  },
  {
    id: 23,
    name: "propanoic acid",
    description: "Three-carbon carboxylic acid",
    difficulty: "easy",
    category: "Carboxylic Acids",
    molecularFormula: "C₃H₆O₂",
    svg: `<!-- Three-carbon chain with carboxyl group -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 120 L150 100"/>
          <!-- Carboxyl group at position 1 -->
          <circle cx="150" cy="100" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="150" y1="100" x2="190" y2="80"/>
          <text x="185" y="75" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">COOH</text>`,
    locants: [
      { x: 145, y: 120, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 45, y: 120, label: "3" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain including carboxyl has 3 carbons.",
        result: "Root name: propan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Carboxyl carbon must be position 1 (IUPAC rule).",
        result: "COOH at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Carboxylic acid is the principal group.",
        result: "Suffix: -oic acid",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Complete Name",
        description: "Combine root with carboxylic acid suffix.",
        result: "Final name: propanoic acid",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 24,
    name: "2-methylcyclohexanone",
    description: "Cyclic ketone with substituent",
    difficulty: "hard",
    category: "Cyclic Compounds",
    molecularFormula: "C₇H₁₂O",
    svg: `<polygon id="chain" points="100,30 160,65 160,135 100,170 40,135 40,65" 
           stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none"/>
          <circle cx="100" cy="30" r="8" fill="hsl(var(--functional-group))" stroke="hsl(var(--molecule-carbon))" strokeWidth="3"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="160" y1="65" x2="190" y2="50"/>
          <text x="85" y="20" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 100, y: 25, label: "1" },
      { x: 165, y: 60, label: "2" },
      { x: 165, y: 140, label: "3" },
      { x: 100, y: 175, label: "4" },
      { x: 35, y: 140, label: "5" },
      { x: 35, y: 60, label: "6" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "Six-membered carbon ring with ketone.",
        result: "Root name: cyclohex-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Ring",
        description: "Ketone carbon gets position 1, number to minimize substituent position.",
        result: "C=O at 1, methyl at 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "Methyl group at position 2.",
        result: "Prefix: 2-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Identify Functional Group",
        description: "Ketone group determines suffix.",
        result: "Suffix: -anone",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 25,
    name: "pent-2-yn-1-ol",
    description: "Alkyne-alcohol combination",
    difficulty: "hard",
    category: "Complex",
    molecularFormula: "C₅H₈O",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 100 L150 75"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 103 L150 78"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 97 L150 72"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M150 75 L200 100 L250 75"/>
          <line id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="50" y1="75" x2="20" y2="60"/>
          <text x="5" y="60" fontSize="16" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "Longest chain containing both functional groups has 5 carbons.",
        result: "Root name: pent-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give alcohol (higher priority) the lowest number.",
        result: "OH at 1, triple bond at 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Both Functional Groups",
        description: "Alcohol takes suffix, alkyne becomes part of base name.",
        result: "Base: pent-2-yn, suffix: -1-ol",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Combine Names",
        description: "Include both functional groups in systematic name.",
        result: "Final name: pent-2-yn-1-ol",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 26,
    name: "2-phenylbutanoic acid",
    description: "Aromatic substituent on carboxylic acid",
    difficulty: "hard",
    category: "Aromatic Compounds",
    molecularFormula: "C₁₀H₁₂O₂",
    svg: `<!-- Main butanoic acid chain -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 120 L150 100 L200 120"/>
          <!-- Carboxyl group at position 1 (end) -->
          <circle cx="200" cy="120" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="200" y1="120" x2="240" y2="100"/>
          <text x="235" y="95" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">COOH</text>
          <!-- Phenyl group at position 2 (simplified representation) -->
          <circle id="substituent" cx="150" cy="100" r="8" fill="hsl(var(--substituent-highlight))" stroke="white" strokeWidth="2"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="150" y1="100" x2="150" y2="60"/>
          <circle cx="150" cy="45" r="15" stroke="hsl(var(--substituent-highlight))" strokeWidth="3" fill="none"/>
          <text x="135" y="50" fontSize="12" fontWeight="bold" fill="hsl(var(--substituent-highlight))">Ph</text>`,
    locants: [
      { x: 195, y: 140, label: "1" },
      { x: 145, y: 120, label: "2" },
      { x: 95, y: 140, label: "3" },
      { x: 45, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "Longest chain including carboxyl has 4 carbons.",
        result: "Root name: butan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Carboxyl carbon must always be position 1 (IUPAC rule).",
        result: "COOH at 1, phenyl at 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Aromatic Substituent",
        description: "Phenyl group (C₆H₅-) at position 2.",
        result: "Prefix: 2-phenyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Identify Functional Group",
        description: "Carboxylic acid is the principal group.",
        result: "Suffix: -oic acid",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 27,
    name: "4-amino-2-methylpentanoic acid",
    description: "Multiple functional groups and substituents",
    difficulty: "hard",
    category: "Complex",
    molecularFormula: "C₆H₁₃NO₂",
    svg: `<!-- Main pentanoic acid carbon chain -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 120 L150 100 L200 120 L250 100"/>
          <!-- Amino group at position 2 -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="120" x2="100" y2="160"/>
          <text x="80" y="175" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">NH₂</text>
          <!-- Methyl substituent at position 4 -->
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="5" x1="200" y1="120" x2="200" y2="160"/>
          <text x="185" y="175" fontSize="14" fontWeight="bold" fill="hsl(var(--substituent-highlight))">CH₃</text>
          <!-- Carboxyl group at position 1 (end) -->
          <circle cx="250" cy="100" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="250" y1="100" x2="290" y2="80"/>
          <text x="285" y="75" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">COOH</text>`,
    locants: [
      { x: 245, y: 100, label: "1" },
      { x: 195, y: 120, label: "2" },
      { x: 145, y: 100, label: "3" },
      { x: 95, y: 120, label: "4" },
      { x: 45, y: 100, label: "5" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "Longest chain including carboxyl has 5 carbons.",
        result: "Root name: pentan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Carboxyl carbon must be position 1 (IUPAC rule).",
        result: "COOH at 1, methyl at 2, amino at 4",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name All Substituents",
        description: "Amino group as prefix, methyl as alkyl substituent.",
        result: "Prefixes: 4-amino-2-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Principal Functional Group",
        description: "Carboxylic acid takes suffix.",
        result: "Suffix: -oic acid",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 28,
    name: "2-bromo-3-chlorobutane",
    description: "Multiple halogen substituents",
    difficulty: "medium",
    category: "Haloalkanes",
    molecularFormula: "C₄H₈BrCl",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100 L150 75 L200 100"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="100" y1="100" x2="100" y2="135"/>
          <line id="substituent" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" x1="150" y1="75" x2="150" y2="40"/>
          <text x="85" y="150" fontSize="14" fontWeight="bold" fill="hsl(var(--substituent-highlight))">Br</text>
          <text x="135" y="35" fontSize="14" fontWeight="bold" fill="hsl(var(--substituent-highlight))">Cl</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "Longest carbon chain has 4 carbons.",
        result: "Root name: but-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give substituents lowest numbers overall.",
        result: "Br at 2, Cl at 3",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Halogen Substituents",
        description: "List halogens alphabetically with positions.",
        result: "Prefixes: 2-bromo-3-chloro",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Add Alkane Suffix",
        description: "No functional groups present.",
        result: "Suffix: -ane",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 29,
    name: "1,3-diethylcyclohexane",
    description: "Multiple substituents on ring",
    difficulty: "hard",
    category: "Cyclic Compounds",
    molecularFormula: "C₁₀H₂₀",
    svg: `<polygon id="chain" points="200,70 260,100 260,160 200,190 140,160 140,100" 
           stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- First ethyl group at position 1 -->
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="200" y1="70" x2="200" y2="40"/>
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="200" y1="40" x2="230" y2="25"/>
          <text x="225" y="30" fontSize="12" fontWeight="bold" fill="hsl(var(--substituent-highlight))">C₂H₅</text>
          <!-- Second ethyl group at position 3 -->
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="260" y1="160" x2="290" y2="175"/>
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="290" y1="175" x2="320" y2="160"/>
          <text x="315" y="170" fontSize="12" fontWeight="bold" fill="hsl(var(--substituent-highlight))">C₂H₅</text>`,
    locants: [
      { x: 200, y: 60, label: "1" },
      { x: 270, y: 95, label: "2" },
      { x: 270, y: 165, label: "3" },
      { x: 200, y: 200, label: "4" },
      { x: 130, y: 165, label: "5" },
      { x: 130, y: 95, label: "6" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "Six-membered carbon ring with ethyl substitutions.",
        result: "Root name: cyclohex-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Ring",
        description: "Number to give substituents lowest numbers.",
        result: "Ethyls at positions 1 and 3",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Multiple Substituents",
        description: "Two ethyl groups at positions 1 and 3.",
        result: "Prefix: 1,3-diethyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Add Cyclic Suffix",
        description: "Cyclic alkane with no functional groups.",
        result: "Suffix: -ane",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 30,
    name: "5-oxohexanoic acid",
    description: "Ketone and carboxylic acid",
    difficulty: "hard",
    category: "Complex",
    molecularFormula: "C₆H₁₀O₃",
    svg: `<!-- Hexanoic acid carbon chain -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 120 L150 100 L200 120 L250 100 L300 120"/>
          <!-- Ketone oxygen at position 2 (double bonded) -->
          <circle cx="100" cy="120" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="120" x2="100" y2="155"/>
          <text x="90" y="170" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <!-- Carboxyl group at position 1 -->
          <circle cx="300" cy="120" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="300" y1="120" x2="340" y2="100"/>
          <text x="335" y="95" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">COOH</text>`,
    locants: [
      { x: 295, y: 120, label: "1" },
      { x: 245, y: 100, label: "2" },
      { x: 195, y: 120, label: "3" },
      { x: 145, y: 100, label: "4" },
      { x: 95, y: 120, label: "5" },
      { x: 45, y: 100, label: "6" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "Longest chain containing carboxyl has 6 carbons.",
        result: "Root name: hexan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Carboxyl carbon must be position 1 (IUPAC rule).",
        result: "COOH at 1, C=O at 5",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Ketone as Substituent",
        description: "Ketone becomes oxo- substituent when carboxyl present.",
        result: "Prefix: 5-oxo",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Principal Functional Group",
        description: "Carboxylic acid takes precedence in suffix.",
        result: "Suffix: -oic acid",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 31,
    name: "hex-2-ene",
    description: "Internal alkene",
    difficulty: "easy",
    category: "Alkenes",
    molecularFormula: "C₆H₁₂",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 100 L150 75"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 105 L150 80"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M150 75 L200 100 L250 75 L300 100"/>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" },
      { x: 295, y: 120, label: "6" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain containing the double bond has 6 carbons.",
        result: "Root name: hex-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the double bond the lowest number.",
        result: "C=C starts at position 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Double bond (C=C) determines the suffix.",
        result: "Suffix: -2-ene",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "No Substituents",
        description: "No other substituents present.",
        result: "Final name: hex-2-ene",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 32,
    name: "but-2-yne",
    description: "Internal alkyne",
    difficulty: "easy",
    category: "Alkynes",
    molecularFormula: "C₄H₆",
    svg: `<path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 100 L150 75"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 103 L150 78"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 97 L150 72"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M150 75 L200 100"/>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain containing the triple bond has 4 carbons.",
        result: "Root name: but-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the triple bond the lowest number.",
        result: "C≡C starts at position 2",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Triple bond (C≡C) determines the suffix.",
        result: "Suffix: -2-yne",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Internal Alkyne",
        description: "Position must be specified for internal alkynes.",
        result: "Final name: but-2-yne",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 33,
    name: "3-methylpent-1-ene",
    description: "Substituted terminal alkene",
    difficulty: "medium",
    category: "Alkenes",
    molecularFormula: "C₆H₁₂",
    svg: `<!-- Double bond at position 1-2 -->
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 75 L100 100"/>
          <path id="functional" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M50 80 L100 105"/>
          <!-- Main carbon chain -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="4" fill="none" d="M100 100 L150 75 L200 100 L250 75"/>
          <!-- Methyl substituent at position 3 -->
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="150" y1="75" x2="150" y2="40"/>
          <text x="135" y="35" fontSize="12" fontWeight="bold" fill="hsl(var(--substituent-highlight))">CH₃</text>`,
    locants: [
      { x: 45, y: 65, label: "1" },
      { x: 95, y: 120, label: "2" },
      { x: 145, y: 65, label: "3" },
      { x: 195, y: 120, label: "4" },
      { x: 245, y: 65, label: "5" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "The longest chain containing the double bond has 5 carbons.",
        result: "Root name: pent-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give the double bond the lowest number.",
        result: "C=C at 1, methyl at 3",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Substituents",
        description: "Methyl group at position 3.",
        result: "Prefix: 3-methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Identify Functional Group",
        description: "Double bond determines the suffix.",
        result: "Suffix: -1-ene",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 34,
    name: "methylbenzene (toluene)",
    description: "Methyl-substituted benzene",
    difficulty: "easy",
    category: "Aromatic Compounds",
    molecularFormula: "C₇H₈",
    svg: `<!-- Benzene ring with IIT JEE standard hexagonal structure -->
          <polygon id="chain" points="200,50 250,75 250,125 200,150 150,125 150,75" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Alternating double bonds in benzene ring (IIT JEE standard) -->
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="215" y1="62" x2="235" y2="80"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="235" y1="120" x2="215" y2="138"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="185" y1="138" x2="165" y2="120"/>
          <!-- Methyl group -->
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="200" y1="50" x2="200" y2="15"/>
          <text x="180" y="12" fontSize="14" fontWeight="bold" fill="hsl(var(--substituent-highlight))">CH₃</text>`,
    locants: [
      { x: 200, y: 40, label: "1" },
      { x: 260, y: 70, label: "2" },
      { x: 260, y: 130, label: "3" },
      { x: 200, y: 160, label: "4" },
      { x: 140, y: 130, label: "5" },
      { x: 140, y: 70, label: "6" }
    ],
    steps: [
      {
        title: "Identify Aromatic Ring",
        description: "Six-membered benzene ring with one substituent.",
        result: "Base name: benzene",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Locate Substituent",
        description: "Methyl group attached to benzene ring.",
        result: "CH₃ at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Apply Aromatic Naming",
        description: "Single substituent on benzene - no numbering needed.",
        result: "Prefix: methyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Common Name Usage",
        description: "Methylbenzene is commonly called toluene.",
        result: "Final name: methylbenzene (toluene)",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 35,
    name: "1,3-dimethylbenzene (m-xylene)",
    description: "Multiple substituents on benzene",
    difficulty: "medium",
    category: "Aromatic Compounds",
    molecularFormula: "C₈H₁₀",
    svg: `<!-- Benzene ring with IIT JEE standard hexagonal structure -->
          <polygon id="chain" points="200,50 250,75 250,125 200,150 150,125 150,75" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Alternating double bonds in benzene ring (IIT JEE standard) -->
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="215" y1="62" x2="235" y2="80"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="235" y1="120" x2="215" y2="138"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="185" y1="138" x2="165" y2="120"/>
          <!-- First methyl group at position 1 -->
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="200" y1="50" x2="200" y2="15"/>
          <text x="180" y="12" fontSize="12" fontWeight="bold" fill="hsl(var(--substituent-highlight))">CH₃</text>
          <!-- Second methyl group at position 3 -->
          <line id="substituent" stroke="hsl(var(--substituent-highlight))" strokeWidth="4" x1="250" y1="125" x2="285" y2="140"/>
          <text x="280" y="150" fontSize="12" fontWeight="bold" fill="hsl(var(--substituent-highlight))">CH₃</text>`,
    locants: [
      { x: 200, y: 40, label: "1" },
      { x: 260, y: 70, label: "2" },
      { x: 260, y: 130, label: "3" },
      { x: 200, y: 160, label: "4" },
      { x: 140, y: 130, label: "5" },
      { x: 140, y: 70, label: "6" }
    ],
    steps: [
      {
        title: "Identify Aromatic Ring",
        description: "Six-membered benzene ring with two methyl substituents.",
        result: "Base name: benzene",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Ring",
        description: "Number to give substituents lowest numbers possible.",
        result: "CH₃ groups at positions 1 and 3",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Multiple Substituents",
        description: "Two identical methyl groups - use 'di' prefix.",
        result: "Prefix: 1,3-dimethyl",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Meta Position",
        description: "1,3-substitution is meta (m-) position.",
        result: "Final name: 1,3-dimethylbenzene (m-xylene)",
        highlight: "none",
        color: "accent"
      }
    ]
  },
  {
    id: 36,
    name: "phenol",
    description: "Hydroxyl group on benzene",
    difficulty: "easy",
    category: "Aromatic Compounds",
    molecularFormula: "C₆H₆O",
    svg: `<!-- Benzene ring with IIT JEE standard hexagonal structure -->
          <polygon id="chain" points="200,50 250,75 250,125 200,150 150,125 150,75" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Alternating double bonds in benzene ring (IIT JEE standard) -->
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="215" y1="62" x2="235" y2="80"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="235" y1="120" x2="215" y2="138"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="185" y1="138" x2="165" y2="120"/>
          <!-- Hydroxyl group -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="50" x2="200" y2="15"/>
          <text x="185" y="12" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [
      { x: 200, y: 40, label: "1" },
      { x: 260, y: 70, label: "2" },
      { x: 260, y: 130, label: "3" },
      { x: 200, y: 160, label: "4" },
      { x: 140, y: 130, label: "5" },
      { x: 140, y: 70, label: "6" }
    ],
    steps: [
      {
        title: "Identify Aromatic Ring",
        description: "Benzene ring with hydroxyl functional group.",
        result: "Base name: benzene",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Locate Functional Group",
        description: "Hydroxyl (-OH) group attached to benzene.",
        result: "OH at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Apply Aromatic Naming",
        description: "Benzene + OH = phenol (special aromatic name).",
        result: "Functional group: -ol",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Special Aromatic Name",
        description: "Hydroxybenzene is commonly called phenol.",
        result: "Final name: phenol",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 37,
    name: "aniline",
    description: "Amino group on benzene",
    difficulty: "easy",
    category: "Aromatic Compounds",
    molecularFormula: "C₆H₇N",
    svg: `<!-- Benzene ring with IIT JEE standard hexagonal structure -->
          <polygon id="chain" points="200,50 250,75 250,125 200,150 150,125 150,75" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Alternating double bonds in benzene ring (IIT JEE standard) -->
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="215" y1="62" x2="235" y2="80"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="235" y1="120" x2="215" y2="138"/>
          <line stroke="hsl(var(--molecule-carbon))" strokeWidth="3" x1="185" y1="138" x2="165" y2="120"/>
          <!-- Amino group -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="50" x2="200" y2="15"/>
          <text x="180" y="12" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">NH₂</text>`,
    locants: [
      { x: 200, y: 40, label: "1" },
      { x: 260, y: 70, label: "2" },
      { x: 260, y: 130, label: "3" },
      { x: 200, y: 160, label: "4" },
      { x: 140, y: 130, label: "5" },
      { x: 140, y: 70, label: "6" }
    ],
    steps: [
      {
        title: "Identify Aromatic Ring",
        description: "Benzene ring with amino functional group.",
        result: "Base name: benzene",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Locate Functional Group",
        description: "Amino (-NH₂) group attached to benzene.",
        result: "NH₂ at position 1",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Apply Aromatic Naming",
        description: "Benzene + NH₂ = aniline (special aromatic name).",
        result: "Functional group: -amine",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Special Aromatic Name",
        description: "Aminobenzene is commonly called aniline.",
        result: "Final name: aniline",
        highlight: "none",
        color: "secondary"
      }
    ]
  },
  {
    id: 36,
    name: "6-oxohexanoic acid",
    description: "Aldehyde group as oxo substituent in carboxylic acid",
    difficulty: "hard",
    category: "Complex",
    molecularFormula: "C₆H₁₀O₃",
    svg: `<!-- Hexanoic acid chain -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 120 L150 100 L200 120 L250 100 L300 120"/>
          <!-- Aldehyde oxygen at position 6 (formyl group as oxo) -->
          <circle cx="50" cy="100" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="50" y1="100" x2="50" y2="135"/>
          <text x="40" y="150" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <!-- Carboxyl group at position 1 -->
          <circle cx="300" cy="120" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="300" y1="120" x2="340" y2="100"/>
          <text x="335" y="95" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">COOH</text>`,
    locants: [
      { x: 295, y: 140, label: "1" },
      { x: 245, y: 120, label: "2" },
      { x: 195, y: 140, label: "3" },
      { x: 145, y: 120, label: "4" },
      { x: 95, y: 140, label: "5" },
      { x: 45, y: 120, label: "6" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "Longest chain containing carboxyl has 6 carbons.",
        result: "Root name: hexan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Carboxyl carbon must be position 1.",
        result: "COOH at 1, C=O at 6",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Name Aldehyde as Substituent",
        description: "Aldehyde becomes oxo- when carboxyl is present.",
        result: "Prefix: 6-oxo",
        highlight: "substituent",
        color: "secondary"
      },
      {
        title: "Principal Functional Group",
        description: "Carboxylic acid takes precedence.",
        result: "Suffix: -oic acid",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 37,
    name: "cyclohexanecarboxamide",
    description: "Amide functional group attached to cyclohexane",
    difficulty: "medium",
    category: "Cyclic Compounds",
    molecularFormula: "C₇H₁₃NO",
    svg: `<!-- Cyclohexane ring -->
          <polygon id="chain" points="200,70 260,100 260,160 200,190 140,160 140,100" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Carboxamide group attached to ring -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="200" y1="70" x2="200" y2="30"/>
          <circle cx="200" cy="20" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="20" x2="230" y2="5"/>
          <text x="225" y="15" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">NH₂</text>
          <text x="185" y="15" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 200, y: 60, label: "1" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "Six-membered carbon ring as parent.",
        result: "Root name: cyclohexane",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Carboxamide (-CONH₂) directly attached to ring.",
        result: "Functional group: carboxamide",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Apply Cyclic Naming Rule",
        description: "For rings, use 'carbox-' prefix with functional group name.",
        result: "Final name: cyclohexanecarboxamide",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 38,
    name: "methyl cyclohexanecarboxylate",
    description: "Ester functional group attached to cyclohexane",
    difficulty: "medium",
    category: "Cyclic Compounds",
    molecularFormula: "C₈H₁₄O₂",
    svg: `<!-- Cyclohexane ring -->
          <polygon id="chain" points="200,70 260,100 260,160 200,190 140,160 140,100" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Ester group attached to ring -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="200" y1="70" x2="200" y2="30"/>
          <circle cx="200" cy="20" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="20" x2="240" y2="10"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="240" y1="10" x2="270" y2="15"/>
          <text x="265" y="20" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">CH₃</text>
          <text x="230" y="15" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="185" y="15" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 200, y: 60, label: "1" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "Six-membered carbon ring as parent.",
        result: "Root name: cyclohexane",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Identify Ester Group",
        description: "Carboxylate ester (-COOCH₃) attached to ring.",
        result: "Functional group: carboxylate",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Name Alkyl Part of Ester",
        description: "Methyl group attached to oxygen.",
        result: "Alkyl part: methyl",
        highlight: "functional",
        color: "secondary"
      },
      {
        title: "Final Assembly",
        description: "Combine alkyl + ring + carboxylate.",
        result: "Final name: methyl cyclohexanecarboxylate",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 39,
    name: "cyclohexanecarbaldehyde",
    description: "Aldehyde functional group attached to cyclohexane",
    difficulty: "medium",
    category: "Cyclic Compounds",
    molecularFormula: "C₇H₁₂O",
    svg: `<!-- Cyclohexane ring -->
          <polygon id="chain" points="200,70 260,100 260,160 200,190 140,160 140,100" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Aldehyde group attached to ring -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="200" y1="70" x2="200" y2="30"/>
          <circle cx="200" cy="20" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="20" x2="230" y2="10"/>
          <text x="225" y="15" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">H</text>
          <text x="185" y="15" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 200, y: 60, label: "1" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "Six-membered carbon ring as parent.",
        result: "Root name: cyclohexane",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Aldehyde (-CHO) directly attached to ring.",
        result: "Functional group: carbaldehyde",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Apply Cyclic Naming Rule",
        description: "For rings, use 'carb-' prefix with aldehyde name.",
        result: "Final name: cyclohexanecarbaldehyde",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 40,
    name: "cyclohexanecarboxylic acid",
    description: "Carboxylic acid functional group attached to cyclohexane",
    difficulty: "medium",
    category: "Cyclic Compounds",
    molecularFormula: "C₇H₁₂O₂",
    svg: `<!-- Cyclohexane ring -->
          <polygon id="chain" points="200,70 260,100 260,160 200,190 140,160 140,100" 
                   stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none"/>
          <!-- Carboxylic acid group attached to ring -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="200" y1="70" x2="200" y2="30"/>
          <circle cx="200" cy="20" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <text x="185" y="10" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">COOH</text>`,
    locants: [
      { x: 200, y: 60, label: "1" }
    ],
    steps: [
      {
        title: "Identify Ring Structure",
        description: "Six-membered carbon ring as parent.",
        result: "Root name: cyclohexane",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Carboxylic acid (-COOH) attached to ring.",
        result: "Functional group: carboxylic acid",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Apply Cyclic Naming Rule",
        description: "For rings, use 'carboxylic acid' suffix.",
        result: "Final name: cyclohexanecarboxylic acid",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 41,
    name: "pentane-2,4-dione",
    description: "Two ketone groups in same molecule",
    difficulty: "hard",
    category: "Complex",
    molecularFormula: "C₅H₈O₂",
    svg: `<!-- Pentane chain -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 120 L150 100 L200 120 L250 100"/>
          <!-- First ketone at position 2 -->
          <circle cx="100" cy="120" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="120" x2="100" y2="155"/>
          <text x="90" y="170" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <!-- Second ketone at position 4 -->
          <circle cx="200" cy="120" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="200" y1="120" x2="200" y2="155"/>
          <text x="190" y="170" fontSize="14" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [
      { x: 45, y: 120, label: "1" },
      { x: 95, y: 140, label: "2" },
      { x: 145, y: 120, label: "3" },
      { x: 195, y: 140, label: "4" },
      { x: 245, y: 120, label: "5" }
    ],
    steps: [
      {
        title: "Find the Parent Chain",
        description: "Longest carbon chain has 5 carbons.",
        result: "Root name: pentan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Number the Chain",
        description: "Number to give ketones lowest numbers.",
        result: "Ketones at positions 2 and 4",
        highlight: "locants",
        color: "primary"
      },
      {
        title: "Multiple Same Functional Groups",
        description: "Two ketone groups require 'di' prefix.",
        result: "Multiple ketones: 2,4-dione",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Final Assembly",
        description: "Combine root + positions + functional group.",
        result: "Final name: pentane-2,4-dione",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 42,
    name: "methanesulphonic acid",
    description: "Sulphonic acid functional group",
    difficulty: "medium",
    category: "Sulphonic Acids",
    molecularFormula: "CH₄O₃S",
    svg: `<!-- Methane carbon -->
          <circle id="chain" cx="100" cy="100" r="12" fill="hsl(var(--molecule-carbon))" stroke="white" strokeWidth="2"/>
          <text x="90" y="105" fontSize="12" fontWeight="bold" fill="white">C</text>
          <!-- Sulphonic acid group -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="100" x2="150" y2="100"/>
          <circle cx="150" cy="100" r="12" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <text x="140" y="105" fontSize="12" fontWeight="bold" fill="white">S</text>
          <!-- Oxygen atoms -->
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="150" y1="100" x2="180" y2="80"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="150" y1="100" x2="180" y2="120"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="150" y1="100" x2="190" y2="100"/>
          <text x="175" y="75" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="175" y="130" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="195" y="105" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [],
    steps: [
      {
        title: "Identify Parent Chain",
        description: "Single carbon atom as parent.",
        result: "Root name: methan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Sulphonic acid group (-SO₃H).",
        result: "Functional group: sulphonic acid",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Apply Naming Rule",
        description: "Replace -e with -sulphonic acid suffix.",
        result: "Final name: methanesulphonic acid",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 43,
    name: "ethanesulphonic acid",
    description: "Sulphonic acid on ethane",
    difficulty: "medium",
    category: "Sulphonic Acids",
    molecularFormula: "C₂H₆O₃S",
    svg: `<!-- Ethane chain -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 100"/>
          <!-- Sulphonic acid group -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="100" x2="150" y2="100"/>
          <circle cx="150" cy="100" r="12" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <text x="140" y="105" fontSize="12" fontWeight="bold" fill="white">S</text>
          <!-- Oxygen atoms -->
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="150" y1="100" x2="180" y2="80"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="150" y1="100" x2="180" y2="120"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="150" y1="100" x2="190" y2="100"/>
          <text x="175" y="75" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="175" y="130" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <text x="195" y="105" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">OH</text>`,
    locants: [
      { x: 45, y: 120, label: "1" },
      { x: 95, y: 120, label: "2" }
    ],
    steps: [
      {
        title: "Identify Parent Chain",
        description: "Two carbon chain as parent.",
        result: "Root name: ethan-",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Identify Functional Group",
        description: "Sulphonic acid group (-SO₃H).",
        result: "Functional group: sulphonic acid",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Apply Naming Rule",
        description: "Replace -e with -sulphonic acid suffix.",
        result: "Final name: ethanesulphonic acid",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 44,
    name: "ethanoic anhydride",
    description: "Acid anhydride functional group",
    difficulty: "hard",
    category: "Acid Anhydrides",
    molecularFormula: "C₄H₆O₃",
    svg: `<!-- Left acetyl group -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 100"/>
          <circle cx="100" cy="100" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="100" y1="100" x2="100" y2="80"/>
          <text x="90" y="75" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <!-- Central oxygen bridge -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="100" x2="150" y2="100"/>
          <circle cx="150" cy="100" r="8" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <text x="140" y="105" fontSize="12" fontWeight="bold" fill="white">O</text>
          <!-- Right acetyl group -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="150" y1="100" x2="200" y2="100"/>
          <circle cx="200" cy="100" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="100" x2="200" y2="80"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M200 100 L250 100"/>
          <text x="190" y="75" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [],
    steps: [
      {
        title: "Identify Functional Group",
        description: "Acid anhydride (-COOCOR) between two acetyl groups.",
        result: "Functional group: anhydride",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Identify Parent Acid",
        description: "Two ethanoic acid units joined.",
        result: "Parent acid: ethanoic acid",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Apply Anhydride Naming",
        description: "Replace 'acid' with 'anhydride' for symmetric anhydrides.",
        result: "Final name: ethanoic anhydride",
        highlight: "functional",
        color: "accent"
      }
    ]
  },
  {
    id: 45,
    name: "ethanoic propanoic anhydride",
    description: "Mixed acid anhydride",
    difficulty: "hard",
    category: "Acid Anhydrides",
    molecularFormula: "C₅H₈O₃",
    svg: `<!-- Left acetyl group (ethanoic) -->
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M50 100 L100 100"/>
          <circle cx="100" cy="100" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="100" y1="100" x2="100" y2="80"/>
          <text x="90" y="75" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>
          <!-- Central oxygen bridge -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="100" y1="100" x2="150" y2="100"/>
          <circle cx="150" cy="100" r="8" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <text x="140" y="105" fontSize="12" fontWeight="bold" fill="white">O</text>
          <!-- Right propyl group (propanoic) -->
          <line id="functional" stroke="hsl(var(--functional-group))" strokeWidth="5" x1="150" y1="100" x2="200" y2="100"/>
          <circle cx="200" cy="100" r="10" fill="hsl(var(--functional-group))" stroke="white" strokeWidth="2"/>
          <line stroke="hsl(var(--functional-group))" strokeWidth="4" x1="200" y1="100" x2="200" y2="80"/>
          <path id="chain" stroke="hsl(var(--molecule-carbon))" strokeWidth="5" fill="none" d="M200 100 L240 100 L270 100"/>
          <text x="190" y="75" fontSize="12" fontWeight="bold" fill="hsl(var(--functional-group))">O</text>`,
    locants: [],
    steps: [
      {
        title: "Identify Functional Group",
        description: "Mixed acid anhydride between different acids.",
        result: "Functional group: anhydride",
        highlight: "functional",
        color: "accent"
      },
      {
        title: "Identify Parent Acids",
        description: "Ethanoic acid (left) and propanoic acid (right).",
        result: "Parent acids: ethanoic + propanoic",
        highlight: "chain",
        color: "primary"
      },
      {
        title: "Apply Mixed Anhydride Naming",
        description: "List both acids alphabetically + 'anhydride'.",
        result: "Final name: ethanoic propanoic anhydride",
        highlight: "functional",
        color: "accent"
      }
    ]
  }
];

const NamingRulesSection = () => {
  const [currentExampleIndex, setCurrentExampleIndex] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [showLocants, setShowLocants] = useState(false);

  const currentExample = namingExamples[currentExampleIndex];
  const steps = currentExample.steps;

  const applyStep = (stepIndex: number) => {
    setCurrentStep(stepIndex);
    // Show locants specifically for step 1 (Number the Chain)
    setShowLocants(stepIndex >= 1);
  };

  const resetAnimation = () => {
    setCurrentStep(-1);
    setShowLocants(false);
  };

  const nextExample = () => {
    setCurrentExampleIndex((prev) => (prev + 1) % namingExamples.length);
    resetAnimation();
  };

  const prevExample = () => {
    setCurrentExampleIndex((prev) => (prev - 1 + namingExamples.length) % namingExamples.length);
    resetAnimation();
  };

  const randomExample = () => {
    const randomIndex = Math.floor(Math.random() * namingExamples.length);
    setCurrentExampleIndex(randomIndex);
    resetAnimation();
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-success';
      case 'medium': return 'text-warning';
      case 'hard': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <motion.section
      className="chemistry-card"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="flex items-center gap-4 mb-6"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <FlaskConical className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold text-foreground">Step-by-Step Naming Process</h2>
      </motion.div>

      <motion.div
        className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <div>
          <h3 className="text-xl font-bold text-foreground mb-2">
            Example {currentExampleIndex + 1} of {namingExamples.length}: {currentExample.name}
          </h3>
          <div className="flex flex-wrap items-center gap-4 text-sm">
            <span className="text-muted-foreground">{currentExample.description}</span>
            <div className="flex items-center gap-2">
              <Atom className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground font-mono">{currentExample.molecularFormula}</span>
            </div>
            <span className={`font-semibold ${getDifficultyColor(currentExample.difficulty)}`}>
              {currentExample.difficulty.toUpperCase()}
            </span>
            <span className="px-2 py-1 bg-primary/10 text-primary rounded-full text-xs">
              {currentExample.category}
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <motion.button
            onClick={prevExample}
            className="btn-chemistry flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ChevronLeft className="h-4 w-4" />
            Previous
          </motion.button>
          
          <motion.button
            onClick={randomExample}
            className="btn-secondary flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Shuffle className="h-4 w-4" />
            Random
          </motion.button>
          
          <motion.button
            onClick={nextExample}
            className="btn-chemistry flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Next
            <ChevronRight className="h-4 w-4" />
          </motion.button>
        </div>
      </motion.div>

      <motion.p
        className="text-lg text-muted-foreground mb-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        Let's deconstruct the name for this molecule together:
      </motion.p>

      <motion.div
        className="mb-8"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <MoleculeViewer 
          svgContent={currentExample.svg}
          locants={currentExample.locants}
          highlight={currentStep >= 0 ? steps[currentStep]?.highlight : "none"}
          showLocants={showLocants}
        />
      </motion.div>

      <motion.div
        className="text-center mb-8"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        <button
          onClick={resetAnimation}
          className="btn-chemistry flex items-center gap-2 mx-auto"
        >
          <RotateCcw className="h-4 w-4" />
          Reset Animation
        </button>
      </motion.div>

      <motion.div
        className="space-y-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7, staggerChildren: 0.1 }}
      >
        {steps.map((step, index) => (
          <motion.div
            key={index}
            className="chemistry-card border transition-all duration-300"
            initial={{ x: -30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.8 + index * 0.1 }}
            whileHover={{ scale: 1.02, y: -2 }}
          >
            <div className="flex justify-between items-center">
              <div className="flex-1">
                <h3 className="text-lg font-semibold mb-2 text-foreground">
                  {index + 1}. {step.title}
                </h3>
                <AnimatePresence>
                  {currentStep >= index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <p className="text-muted-foreground text-sm mb-2">
                        {step.description}
                      </p>
                      <p className="font-semibold text-primary">
                        {step.result}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              <motion.button
                onClick={() => applyStep(index)}
                className={`btn-${step.color === 'primary' ? 'chemistry' : step.color} ml-4`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Play className="h-4 w-4" />
              </motion.button>
            </div>
          </motion.div>
        ))}

        <motion.div
          className="p-6 rounded-xl bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20"
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
        >
          <h3 className="text-xl font-semibold text-center mb-4 text-foreground">
            Final Assembly
          </h3>
          <motion.div
            className="text-center p-6 bg-white rounded-xl shadow-lg"
            whileHover={{ scale: 1.02 }}
          >
            <motion.p
              className="text-3xl font-extrabold text-foreground tracking-tight"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              {currentExample.name}
            </motion.p>
            <p className="text-muted-foreground mt-2 text-sm">
              {currentExample.description}
            </p>
          </motion.div>
        </motion.div>
      </motion.div>
    </motion.section>
  );
};

export default NamingRulesSection;