import { motion } from "framer-motion";
import { BookOpen, Lightbulb, Target, Zap } from "lucide-react";

const IntroductionSection = () => {
  const components = [
    {
      title: "Parent Chain",
      description: "The longest continuous chain of carbon atoms. It's the 'family name' of the molecule.",
      icon: Target,
      color: "primary"
    },
    {
      title: "Functional Group",
      description: "The reactive part that determines the chemical 'personality' and suffix.",
      icon: Zap,
      color: "accent"
    },
    {
      title: "Substituents",
      description: "Branches off the parent chain. These become prefixes in the name.",
      icon: Lightbulb,
      color: "secondary"
    },
    {
      title: "Locants",
      description: "Numbers that specify the exact position of groups like house addresses.",
      icon: BookOpen,
      color: "success"
    }
  ];

  return (
    <motion.section
      className="chemistry-card slide-in"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.div
        className="flex items-center gap-4 mb-6"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <BookOpen className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold text-foreground">What is IUPAC Nomenclature?</h2>
      </motion.div>

      <motion.div
        className="space-y-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, staggerChildren: 0.1 }}
      >
        <motion.p
          className="text-lg text-muted-foreground leading-relaxed"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          With millions of organic compounds, a universal naming system is essential. The{" "}
          <span className="font-semibold text-primary">International Union of Pure and Applied Chemistry (IUPAC)</span>{" "}
          provides this system, ensuring any chemist worldwide can draw the exact structure from its name.
        </motion.p>

        <motion.div
          className="p-6 bg-primary/5 border-l-4 border-primary rounded-r-xl"
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          whileHover={{ x: 4 }}
        >
          <div className="flex items-start gap-3">
            <Lightbulb className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-bold text-primary mb-2">Analogy</h4>
              <p className="text-primary/80">
                An IUPAC name is like a molecule's universal address. Just as an address points to one specific building, 
                a name like "2-methylpropan-1-ol" points to one specific molecular structure.
              </p>
            </div>
          </div>
        </motion.div>

        <motion.h3
          className="text-2xl font-semibold mt-8 mb-6 text-foreground"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          Core Components of a Name
        </motion.h3>

        <motion.div
          className="grid md:grid-cols-2 gap-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, staggerChildren: 0.1 }}
        >
          {components.map((component, index) => {
            const Icon = component.icon;
            return (
              <motion.div
                key={component.title}
                className={`p-6 rounded-xl border transition-all duration-300 hover:scale-105 cursor-pointer group`}
                style={{
                  backgroundColor: `hsl(var(--${component.color}) / 0.05)`,
                  borderColor: `hsl(var(--${component.color}) / 0.2)`
                }}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 + index * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={`p-3 rounded-lg group-hover:scale-110 transition-transform`}
                    style={{ backgroundColor: `hsl(var(--${component.color}) / 0.1)` }}
                  >
                    <Icon
                      className="h-6 w-6"
                      style={{ color: `hsl(var(--${component.color}))` }}
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg text-foreground mb-2">{component.title}</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {component.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </motion.div>
    </motion.section>
  );
};

export default IntroductionSection;